================================================================
NEON CLUB — 142 BPM shot sequence
================================================================
11.00 s · 1920x1080 master · 30 fps · H.264 + AAC stereo
Timing locked to 142 BPM (1 beat = 0.422535 s)

STRUKTUR / STRUCTURE
----------------------------------------------------------------
  0.00 – 5.07 s   Shot 02  Entrance push-in        (source: image-2)
  5.07 – 5.93 s   Transition  Cyan laser wipe      (26 frames = 2 beats)
  5.93 – 11.00 s  Shot 03   Club wide push-in      (source: image-1)

Cut laser mendarat tepat di beat 12. Setiap shot = 12 beat.
The laser cut lands exactly on beat 12. Each shot = 12 beats.

ISI FILE / WHAT'S INSIDE
----------------------------------------------------------------
neon-club-loop.mp4              10.3 MB  1080p master, kualitas penuh + audio
neon-club-loop-720p.mp4          6.3 MB  720p H.264 Main L3.1, paling kompatibel
neon-club-loop-540p.mp4          2.6 MB  540p ringan untuk share / low bandwidth
neon-club-loop-720p-muted.mp4    6.1 MB  720p tanpa audio (untuk autoplay)
neon-club-loop-720p.webm         4.6 MB  720p VP9 + Opus (WebM)
neon-club-poster.jpg             537 KB  still 1080p saat club ter-reveal
neon-club-entrance.jpg           342 KB  still 1080p shot 02
neon-club-club.jpg               516 KB  still 1080p shot 03
neon-club-storyboard.jpg         765 KB  contact sheet 12 frame kunci
CHECKSUMS.txt                             sha256 semua file di atas

TIPS PEMUTARAN / PLAYBACK TIPS
----------------------------------------------------------------
- Kalau versi 1080p patah-patah atau tidak mau autoplay, pakai
  540p atau versi -muted (autoplay audio sering diblokir browser).
- If the 1080p master stalls or will not autoplay, use the 540p
  or the -muted file (browsers block autoplay with audio).
- Format paling universal: neon-club-loop-720p.mp4

CATATAN TEKNIS / TECHNICAL NOTES
----------------------------------------------------------------
- Gerak kamera = simulasi dolly (inverse-mapped warp), bukan cross-fade.
- Shot 03 punya depth parallax per-baris: lantai dekat mengembang lebih
  cepat dari plafon jauh -> parallax travel yang nyata.
- Shot 02 sengaja TANPA warping lokal: subjek hanya kena gerak kamera
  global + pass cahaya, jadi identitas & wardrobe tetap rigid.
- Audio disintesis dari nol (tanpa sample): kick 4-on-the-floor, clap di
  ketukan 2 & 4, bass offbeat A minor, pad Am9, riser 4 beat ke arah cut,
  sub-boom + crash di cut, whoosh laser mengikuti transisi.
- Deterministik: frame ke-N selalu identik, jadi aman untuk re-render.

QA TERUKUR / MEASURED QA (encoded master, 320x180 luma, mean frame delta)
----------------------------------------------------------------
  shot 02   mean 3.48   max 4.72
  wipe      3 -> 13.7 -> 38 (pada tear) -> 3
  shot 03   mean 3.33   max 5.02
  odd/even motion ratio 0.980  -> tidak ada flicker
  luma sd 3.9 per shot       -> tidak ada exposure pumping
  cut boundary wipe->shot03  -> delta 0.00 (hand-off mulus)

Dibuat dengan renderer prosedural di repo: tools/render/
(render_timeline.py, make_audio.py, qa_wipe.py)
